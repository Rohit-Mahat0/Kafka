

This directory contains Kafka Producer example.

The demo application takes following Program Arguments:

`nse05 nse06 /data/NSE05NOV2018BHAV.csv /data/NSE06NOV2018BHAV.csv`