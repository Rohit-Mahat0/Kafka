

This directory contains Kafka Producer example.

The demo application takes following Program Arguments:

`pos 2 1000`