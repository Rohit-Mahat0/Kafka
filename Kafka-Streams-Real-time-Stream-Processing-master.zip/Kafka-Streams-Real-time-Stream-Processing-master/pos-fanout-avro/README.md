This directory contains Kafka Streams example.

The project uses avro-maven-plugin to generate classes. 

Do not manually modify classes in types directory