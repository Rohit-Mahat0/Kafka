

This directory contains Kafka Producer example.

The demo application takes following Program Arguments:

`2 test-group nse-bhav-json`