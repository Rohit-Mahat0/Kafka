

This directory contains Kafka Producer example.

The demo application takes following Program Arguments:

`nse-bhav-avro group1`