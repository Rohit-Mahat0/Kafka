
This directory contains Kafka Producer and a Kafka Streams consumer.

The demo application implements two main methods
and they take following Program Arguments:

HelloProducer class takes two arguments

`hello-producer 10`

HelloStreams class takes one argument

`hello-producer`
