POS Simulator that generates random invoices in Avro

The demo application takes following Program Arguments:

pos 2 15000