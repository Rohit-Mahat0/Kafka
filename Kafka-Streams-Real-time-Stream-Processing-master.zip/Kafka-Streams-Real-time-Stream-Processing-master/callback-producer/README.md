

This directory contains Kafka Producer example.

The demo application takes following Program Arguments:

`hello-producer 10`