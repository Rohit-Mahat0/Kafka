This directory contains Kafka Streams example.

The project uses JsonSchema2Pojo maven plugin to generate classes.
Do not manually modify classes in types directory 