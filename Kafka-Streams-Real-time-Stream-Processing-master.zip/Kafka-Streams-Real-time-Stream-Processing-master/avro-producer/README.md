

This directory contains Kafka Producer example.

The demo application takes following Program Arguments:

`nse-bhav-avro /data/NSE05NOV2018BHAV.csv /data/NSE06NOV2018BHAV.csv`